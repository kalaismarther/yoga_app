import 'package:flutter/material.dart';

class AppColors {
  static const Color orange = Color(0xFFF94D1F);
  static const Color borderGrey = Color(0xFFE1E1E1);
}
