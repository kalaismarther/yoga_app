class PaymentService {
  //LIVE KEY : rzp_live_x7VVMxCcSJbQ4E
  //TEST KEY : rzp_test_tRFRt6Lzrf9tft
  static const String key = 'rzp_live_x7VVMxCcSJbQ4E';
  static const String name = 'Sera Yoga';
  static const String mobile = '1234567890';
  static const String email = 'serayoga2000@gmail.com';
  //
}
