class SearchSuccessModel {
  final List<dynamic> yogaList;

  SearchSuccessModel({required this.yogaList});
}
