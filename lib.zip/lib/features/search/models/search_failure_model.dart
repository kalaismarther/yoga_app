class SearchFailureModel {
  final String reason;

  SearchFailureModel({required this.reason});
}
