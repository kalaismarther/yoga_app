part of 'testimonial_bloc.dart';

@immutable
sealed class TestimonialEvent {}

class GetTestimonialsEvent extends TestimonialEvent {}
