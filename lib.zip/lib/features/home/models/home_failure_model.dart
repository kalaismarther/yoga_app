class HomeFailureModel {
  final String reason;

  HomeFailureModel({required this.reason});
}
