class HomeSuccessModel {
  final String userName;
  final List<dynamic> yogaCoursesList;

  HomeSuccessModel({required this.userName, required this.yogaCoursesList});
}
