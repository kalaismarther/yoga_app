class VerificationFailureModel {
  final String error;

  VerificationFailureModel({required this.error});

  String errorMessage() => error;
}
