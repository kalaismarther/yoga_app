class ResendSuccessModel {
  final String message;

  ResendSuccessModel({required this.message});
}
