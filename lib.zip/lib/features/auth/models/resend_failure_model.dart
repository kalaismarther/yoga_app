class ResendFailureModel {
  final String reason;

  ResendFailureModel({required this.reason});
}
