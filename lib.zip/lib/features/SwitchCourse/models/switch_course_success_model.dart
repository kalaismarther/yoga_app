class SwitchCourseSuccessModel {
  final String message;

  SwitchCourseSuccessModel({required this.message});
}
