class SwitchCourseFailureModel {
  final String reason;

  SwitchCourseFailureModel({required this.reason});
}
