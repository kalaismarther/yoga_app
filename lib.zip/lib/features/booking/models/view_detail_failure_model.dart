class ViewDetailFailureModel {
  final String reason;

  ViewDetailFailureModel({required this.reason});
}
