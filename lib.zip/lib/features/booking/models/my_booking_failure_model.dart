class MyBookingFailureModel {
  final String reason;

  MyBookingFailureModel({required this.reason});
}
