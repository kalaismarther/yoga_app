import 'package:yoga_app/features/walkthrough/models/banner_model.dart';

class WalkthroughSuccessModel {
  final List<BannerModel> banners;

  WalkthroughSuccessModel({required this.banners});
}
