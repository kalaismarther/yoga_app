class WalkthroughFailureModel {
  final String reason;

  WalkthroughFailureModel({required this.reason});
}
