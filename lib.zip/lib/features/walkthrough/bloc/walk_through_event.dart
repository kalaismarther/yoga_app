part of 'walk_through_bloc.dart';

@immutable
sealed class WalkThroughEvent {}

class GetWalkThroughContentEvent extends WalkThroughEvent {}
