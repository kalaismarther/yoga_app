class UpdateProfileFailureModel {
  final String error;

  UpdateProfileFailureModel({required this.error});
}
