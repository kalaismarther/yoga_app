class EditProfileFailureModel {
  final String error;

  EditProfileFailureModel({required this.error});
}
