class YogaDetailFailureModel {
  final String reason;

  YogaDetailFailureModel({required this.reason});
}
