class BookingFailureModel {
  final String failureMessage;

  BookingFailureModel({required this.failureMessage});
}
