class LogoutSuccessModel {
  final String message;

  LogoutSuccessModel({required this.message});
}
