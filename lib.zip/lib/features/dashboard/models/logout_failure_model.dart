class LogoutFailureModel {
  final String reason;

  LogoutFailureModel({required this.reason});
}
